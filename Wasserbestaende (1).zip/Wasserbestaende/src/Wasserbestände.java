
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.chrono.ChronoLocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Created: 22.11.2021
 *
 * @author Kilian Baier (20190608)
 */
public class Wasserbestände {

    private static Map<LocalDateTime, Integer> levels;

    public Wasserbestände() {
        levels = new TreeMap<>();
    }

    public Wasserbestände(String file) {
        levels = new TreeMap<>();
        readFromFile(file);
    }


    public Map<LocalDateTime, Integer> readFromFile(String filename) {
        try {
            File myObj = new File(filename);
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                addtoMap(data);
            }
        } catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
        }
        return levels;
    }

    private void addtoMap(String data) {
        try {
            String[] str = data.split("\t");
            String fulldate = str[0];
            LocalDateTime dateTime = parseDate(fulldate);
            levels.put(dateTime, Integer.parseInt(str[2]));
        }
        catch (Exception e){
        }
    }


    public Map<LocalDateTime, Integer> highest(LocalDateTime from, LocalDateTime to) {
        Map<LocalDateTime, Integer> newMap = new TreeMap<>();
        int highest = 0;
        int count = 0;
        while(count <= 1) {

            for (var i : levels.entrySet()) {
                if (i.getKey().isBefore(from) || i.getKey().isAfter(to)) {
                    continue;
                } else {
                    if (i.getValue() > highest && count == 0) {
                        highest = i.getValue();
                    }
                    if (count == 1) {
                        if (i.getValue() == highest) {
                            newMap.put(i.getKey(), i.getValue());
                        }
                    }
                }
            }
            count++;
        }

        return newMap;
    }

    public double average(LocalDateTime from, LocalDateTime to) {
        double count = 0;
        double countaverage = 0;

        for (var i : levels.entrySet()) {
            if (i.getKey().isBefore(from) || i.getKey().isAfter(to)) {
                continue;
            } else {
                count++;
                countaverage += i.getValue();
            }
        }
        return countaverage / count;
    }

    public static LocalDateTime parseDate(String date) {
        return LocalDateTime.parse(date, DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"));
    }

    public static void main(String[] args) {
        final DecimalFormat df1 = new DecimalFormat("0.00");
        Wasserbestände test = new Wasserbestände("ressources/Datei_Wasserstand_data_25268_W_MONTH.txt");
        LocalDateTime to = parseDate("13.07.2009 23:55");
        LocalDateTime from = parseDate("15.06.2009 00:00");
        System.out.println(df1.format(test.average(from, to)));
        System.out.println(test.highest(from, to).size());
    }
}


